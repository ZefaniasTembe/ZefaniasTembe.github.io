package bigsoftwareschool;

public class BigSoftwareSchool {

    public static void main(String[] args) {
        // Testando as funcionalidades finais
        
    }
    
}
